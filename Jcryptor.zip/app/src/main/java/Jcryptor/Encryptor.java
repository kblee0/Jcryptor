package Jcryptor;

public abstract class Encryptor {
    public static final int ENCRYPT_MODE = 1;
    public static final int DECRYPT_MODE = 2;

    private int procMode = ENCRYPT_MODE;

    public Encryptor setProcMode(int procMode) {
        this.procMode = procMode;
        return this;
    }
    public String doProc(String message) throws Exception {
        return procMode == ENCRYPT_MODE ? encrypt(message) : decrypt(message);
    }

    public abstract Encryptor setPassword(String password);
    public abstract String encrypt(String message) throws Exception;
    public abstract String decrypt(String encryptedMessage) throws Exception;

}
